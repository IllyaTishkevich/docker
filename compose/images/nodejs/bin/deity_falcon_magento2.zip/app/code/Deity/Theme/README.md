### Deity Theme module

Module is contains configuration for resources generated for frontend.
Such as:
- image dimensions